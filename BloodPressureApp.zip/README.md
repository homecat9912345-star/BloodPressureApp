# Blood Pressure Tracker - 血压记录 App

## 项目介绍
这是一个功能完整的安卓血压记录应用，采用 Material Design 3 风格，主色调为深蓝紫色。

## 功能特性
- ✅ 血压记录（收缩压/舒张压/心率）
- ✅ 自动分类（正常/偏高/1级高血压/2级高血压）
- ✅ 历史记录列表（可滑动删除）
- ✅ 趋势曲线图（MPAndroidChart，支持7/14/30天）
- ✅ 近7次平均值统计
- ✅ 血压标准参考表
- ✅ Room 数据库本地存储
- ✅ 备注功能

## 编译方法

### 方法一：使用 Android Studio（推荐）
1. 下载安装 [Android Studio](https://developer.android.com/studio)
2. 打开 BloodPressureApp 文件夹
3. 等待 Gradle 同步完成
4. 点击 Build > Build Bundle(s) / APK(s) > Build APK(s)
5. APK 在 `app/build/outputs/apk/debug/` 目录下

### 方法二：命令行编译
```bash
# 确保已安装 Android SDK（ANDROID_HOME 环境变量已设置）
cd BloodPressureApp
./gradlew assembleDebug
# APK 输出在 app/build/outputs/apk/debug/app-debug.apk
```

### 方法三：在线编译（无需本地 SDK）
1. 将 BloodPressureApp 文件夹上传到 GitHub
2. 使用 GitHub Actions 自动编译（添加 .github/workflows/build.yml）
3. 或使用 [Appetize.io](https://appetize.io) 在线预览

## 项目结构
```
BloodPressureApp/
├── app/
│   ├── build.gradle              # 应用级 Gradle 配置
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/health/bptracker/
│       │   ├── BPRecord.java         # 数据实体
│       │   ├── BPRecordDao.java      # 数据库 DAO
│       │   ├── BPDatabase.java       # Room 数据库
│       │   ├── BPRepository.java     # 数据仓库
│       │   ├── BPViewModel.java      # ViewModel
│       │   ├── BPRecordAdapter.java  # RecyclerView 适配器
│       │   ├── MainActivity.java     # 主 Activity（底部导航）
│       │   ├── HomeFragment.java     # 首页（最新血压+统计）
│       │   ├── HistoryFragment.java  # 历史记录列表
│       │   ├── ChartFragment.java    # 趋势图表
│       │   └── AddRecordActivity.java # 添加记录
│       └── res/
│           ├── layout/               # UI 布局文件
│           ├── values/               # 颜色/字符串/主题
│           └── drawable/             # 图形资源
├── build.gradle                  # 项目级 Gradle 配置
└── settings.gradle
```

## 依赖库
- **MPAndroidChart v3.1.0** - 图表绘制
- **Room 2.6.1** - 本地数据库
- **Material Design 3** - UI 组件
- **ViewModel + LiveData** - 架构组件
