## 本地构建步骤

### 第一步：安装 Android Studio
1. 前往 https://developer.android.com/studio 下载 Android Studio
2. 安装时勾选 "Android SDK" 和 "Android SDK Platform-Tools"

### 第二步：打开项目
1. 打开 Android Studio
2. 选择 "Open" → 选择本文件夹（BloodPressureApp）
3. 等待 Gradle 自动同步（首次需要下载依赖，约需5-10分钟）

### 第三步：构建 APK
方法A - 图形界面：
  菜单 Build → Build Bundle(s) / APK(s) → Build APK(s)
  等待完成后点击提示中的 "locate" 定位 APK 文件

方法B - 命令行：
  在项目根目录执行：
  Windows: gradlew.bat assembleDebug
  Linux/Mac: ./gradlew assembleDebug

APK 输出路径：app/build/outputs/apk/debug/app-debug.apk

### 第四步：安装到手机
1. 手机开启"开发者选项"→"允许USB调试"
2. 用 USB 连接手机
3. Android Studio 顶部点击 Run 按钮
   或命令行：adb install app/build/outputs/apk/debug/app-debug.apk

---
## 在线编译（无需本地安装）

### 方法一：GitHub Actions
1. 在 GitHub 新建仓库
2. 上传本项目所有文件（包含 .github 文件夹）
3. 自动触发 Actions，构建完成后下载 APK artifact

### 方法二：Gitpod
1. 将项目推送到 GitHub
2. 访问 https://gitpod.io/#<你的仓库URL>
3. 在终端执行：./gradlew assembleDebug
