package com.health.bptracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BPRecordAdapter extends ListAdapter<BPRecord, BPRecordAdapter.ViewHolder> {

    private static final DiffUtil.ItemCallback<BPRecord> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<BPRecord>() {
                @Override
                public boolean areItemsTheSame(@NonNull BPRecord oldItem, @NonNull BPRecord newItem) {
                    return oldItem.id == newItem.id;
                }

                @Override
                public boolean areContentsTheSame(@NonNull BPRecord oldItem, @NonNull BPRecord newItem) {
                    return oldItem.systolic == newItem.systolic &&
                            oldItem.diastolic == newItem.diastolic &&
                            oldItem.heartRate == newItem.heartRate;
                }
            };

    public BPRecordAdapter() {
        super(DIFF_CALLBACK);
    }

    public BPRecord getRecordAt(int position) {
        return getItem(position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_bp_record, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BPRecord record = getItem(position);
        holder.bind(record);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSystolic, tvDiastolic, tvHeartRate, tvDate, tvTime, tvCategory, tvNote;
        CardView cardView;
        View indicatorBar;

        ViewHolder(View itemView) {
            super(itemView);
            tvSystolic = itemView.findViewById(R.id.tv_item_systolic);
            tvDiastolic = itemView.findViewById(R.id.tv_item_diastolic);
            tvHeartRate = itemView.findViewById(R.id.tv_item_heart);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            tvTime = itemView.findViewById(R.id.tv_item_time);
            tvCategory = itemView.findViewById(R.id.tv_item_category);
            tvNote = itemView.findViewById(R.id.tv_item_note);
            cardView = itemView.findViewById(R.id.card_record);
            indicatorBar = itemView.findViewById(R.id.indicator_bar);
        }

        void bind(BPRecord record) {
            tvSystolic.setText(String.valueOf(record.systolic));
            tvDiastolic.setText(String.valueOf(record.diastolic));
            tvHeartRate.setText(String.valueOf(record.heartRate));
            tvCategory.setText(record.category);

            SimpleDateFormat dateFmt = new SimpleDateFormat("MM-dd", Locale.CHINA);
            SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.CHINA);
            Date date = new Date(record.timestamp);
            tvDate.setText(dateFmt.format(date));
            tvTime.setText(timeFmt.format(date));

            if (record.note != null && !record.note.isEmpty()) {
                tvNote.setVisibility(View.VISIBLE);
                tvNote.setText(record.note);
            } else {
                tvNote.setVisibility(View.GONE);
            }

            // 根据分类设置颜色
            int color;
            switch (record.category) {
                case "正常": color = 0xFF4CAF50; break;
                case "偏高": color = 0xFFFF9800; break;
                case "1级高血压": color = 0xFFFF5722; break;
                default: color = 0xFFF44336; break;
            }
            tvCategory.setTextColor(color);
            indicatorBar.setBackgroundColor(color);
        }
    }
}
