package com.health.bptracker;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.chip.ChipGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChartFragment extends Fragment {

    private BPViewModel viewModel;
    private LineChart lineChart;
    private ChipGroup chipGroup;
    private TextView tvChartEmpty;
    private int currentDays = 7;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chart, container, false);

        lineChart = view.findViewById(R.id.line_chart);
        chipGroup = view.findViewById(R.id.chip_group);
        tvChartEmpty = view.findViewById(R.id.tv_chart_empty);

        setupChart();

        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_7days) currentDays = 7;
            else if (id == R.id.chip_14days) currentDays = 14;
            else if (id == R.id.chip_30days) currentDays = 30;
            loadChartData();
        });

        viewModel = new ViewModelProvider(requireActivity()).get(BPViewModel.class);
        viewModel.getAllRecords().observe(getViewLifecycleOwner(), records -> loadChartData());

        return view;
    }

    private void setupChart() {
        lineChart.setDrawGridBackground(false);
        lineChart.setBackgroundColor(Color.WHITE);
        lineChart.getDescription().setEnabled(false);
        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);
        lineChart.setPinchZoom(true);
        lineChart.setNoDataText("暂无数据");

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(-30f);
        xAxis.setTextColor(Color.parseColor("#666666"));
        xAxis.setTextSize(10f);

        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setDrawGridLines(true);
        leftAxis.setGridColor(Color.parseColor("#E0E0E0"));
        leftAxis.setAxisMinimum(40f);
        leftAxis.setAxisMaximum(200f);
        leftAxis.setTextColor(Color.parseColor("#666666"));

        lineChart.getAxisRight().setEnabled(false);

        Legend legend = lineChart.getLegend();
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextSize(12f);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
    }

    private void loadChartData() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -currentDays);
        long startTime = cal.getTimeInMillis();

        List<BPRecord> records = viewModel.getRecordsSince(startTime);

        if (records == null || records.isEmpty()) {
            tvChartEmpty.setVisibility(View.VISIBLE);
            lineChart.setVisibility(View.GONE);
            return;
        }

        tvChartEmpty.setVisibility(View.GONE);
        lineChart.setVisibility(View.VISIBLE);

        ArrayList<Entry> systolicEntries = new ArrayList<>();
        ArrayList<Entry> diastolicEntries = new ArrayList<>();
        ArrayList<Entry> heartRateEntries = new ArrayList<>();
        final ArrayList<String> labels = new ArrayList<>();

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd HH:mm", Locale.CHINA);

        for (int i = 0; i < records.size(); i++) {
            BPRecord r = records.get(i);
            systolicEntries.add(new Entry(i, r.systolic));
            diastolicEntries.add(new Entry(i, r.diastolic));
            heartRateEntries.add(new Entry(i, r.heartRate));
            labels.add(sdf.format(new Date(r.timestamp)));
        }

        // 收缩压数据集
        LineDataSet systolicSet = new LineDataSet(systolicEntries, "收缩压（高压）");
        systolicSet.setColor(Color.parseColor("#F44336"));
        systolicSet.setCircleColor(Color.parseColor("#F44336"));
        systolicSet.setLineWidth(2.5f);
        systolicSet.setCircleRadius(4f);
        systolicSet.setDrawValues(false);
        systolicSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        // 舒张压数据集
        LineDataSet diastolicSet = new LineDataSet(diastolicEntries, "舒张压（低压）");
        diastolicSet.setColor(Color.parseColor("#2196F3"));
        diastolicSet.setCircleColor(Color.parseColor("#2196F3"));
        diastolicSet.setLineWidth(2.5f);
        diastolicSet.setCircleRadius(4f);
        diastolicSet.setDrawValues(false);
        diastolicSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        // 心率数据集
        LineDataSet heartRateSet = new LineDataSet(heartRateEntries, "心率");
        heartRateSet.setColor(Color.parseColor("#4CAF50"));
        heartRateSet.setCircleColor(Color.parseColor("#4CAF50"));
        heartRateSet.setLineWidth(2f);
        heartRateSet.setCircleRadius(3.5f);
        heartRateSet.setDrawValues(false);
        heartRateSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        heartRateSet.enableDashedLine(10f, 5f, 0f);

        LineData lineData = new LineData(systolicSet, diastolicSet, heartRateSet);

        lineChart.getXAxis().setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                if (idx >= 0 && idx < labels.size()) {
                    return labels.get(idx);
                }
                return "";
            }
        });

        lineChart.setData(lineData);
        lineChart.invalidate();
        lineChart.animateX(800);
    }
}
