package com.health.bptracker;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BPRecordDao {
    @Insert
    void insert(BPRecord record);

    @Delete
    void delete(BPRecord record);

    @Update
    void update(BPRecord record);

    @Query("SELECT * FROM blood_pressure_records ORDER BY timestamp DESC")
    LiveData<List<BPRecord>> getAllRecords();

    @Query("SELECT * FROM blood_pressure_records ORDER BY timestamp DESC LIMIT :limit")
    LiveData<List<BPRecord>> getRecentRecords(int limit);

    @Query("SELECT * FROM blood_pressure_records WHERE timestamp >= :startTime ORDER BY timestamp ASC")
    List<BPRecord> getRecordsSince(long startTime);

    @Query("DELETE FROM blood_pressure_records")
    void deleteAll();
}
