package com.health.bptracker;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;

public class AddRecordActivity extends AppCompatActivity {

    private TextInputEditText etSystolic, etDiastolic, etNote;
    private SeekBar seekBarHeart;
    private TextView tvHeartValue;
    private Button btnSave;
    private BPViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        etSystolic = findViewById(R.id.et_systolic);
        etDiastolic = findViewById(R.id.et_diastolic);
        etNote = findViewById(R.id.et_note);
        seekBarHeart = findViewById(R.id.seekbar_heart);
        tvHeartValue = findViewById(R.id.tv_heart_value);
        btnSave = findViewById(R.id.btn_save);

        // 心率默认70，范围40-180
        seekBarHeart.setMax(140); // 40 + max140 = 180
        seekBarHeart.setProgress(30); // 40 + 30 = 70
        tvHeartValue.setText("70 次/分");

        seekBarHeart.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int heartRate = progress + 40;
                tvHeartValue.setText(heartRate + " 次/分");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        viewModel = new ViewModelProvider(this).get(BPViewModel.class);

        btnSave.setOnClickListener(v -> saveRecord());
    }

    private void saveRecord() {
        String sysStr = etSystolic.getText() != null ? etSystolic.getText().toString().trim() : "";
        String diaStr = etDiastolic.getText() != null ? etDiastolic.getText().toString().trim() : "";

        if (TextUtils.isEmpty(sysStr)) {
            etSystolic.setError("请输入收缩压");
            return;
        }
        if (TextUtils.isEmpty(diaStr)) {
            etDiastolic.setError("请输入舒张压");
            return;
        }

        int systolic = Integer.parseInt(sysStr);
        int diastolic = Integer.parseInt(diaStr);
        int heartRate = seekBarHeart.getProgress() + 40;
        String note = etNote.getText() != null ? etNote.getText().toString().trim() : "";

        if (systolic < 60 || systolic > 250) {
            etSystolic.setError("请输入有效的收缩压（60-250）");
            return;
        }
        if (diastolic < 40 || diastolic > 150) {
            etDiastolic.setError("请输入有效的舒张压（40-150）");
            return;
        }
        if (diastolic >= systolic) {
            etDiastolic.setError("舒张压应小于收缩压");
            return;
        }

        BPRecord record = new BPRecord(systolic, diastolic, heartRate, note, System.currentTimeMillis());
        viewModel.insert(record);

        Toast.makeText(this, "记录保存成功！", Toast.LENGTH_SHORT).show();
        finish();
    }
}
