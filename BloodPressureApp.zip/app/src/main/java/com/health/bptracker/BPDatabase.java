package com.health.bptracker;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {BPRecord.class}, version = 1, exportSchema = false)
public abstract class BPDatabase extends RoomDatabase {
    private static volatile BPDatabase INSTANCE;

    public abstract BPRecordDao bpRecordDao();

    public static BPDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (BPDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            BPDatabase.class,
                            "bp_database"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}
