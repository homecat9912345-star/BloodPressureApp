package com.health.bptracker;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BPRepository {
    private final BPRecordDao dao;
    private final ExecutorService executor;
    private final LiveData<List<BPRecord>> allRecords;

    public BPRepository(Application application) {
        BPDatabase db = BPDatabase.getInstance(application);
        dao = db.bpRecordDao();
        executor = Executors.newSingleThreadExecutor();
        allRecords = dao.getAllRecords();
    }

    public LiveData<List<BPRecord>> getAllRecords() {
        return allRecords;
    }

    public LiveData<List<BPRecord>> getRecentRecords(int limit) {
        return dao.getRecentRecords(limit);
    }

    public List<BPRecord> getRecordsSince(long startTime) {
        try {
            return Executors.newSingleThreadExecutor().submit(() ->
                    dao.getRecordsSince(startTime)).get();
        } catch (Exception e) {
            return null;
        }
    }

    public void insert(BPRecord record) {
        executor.execute(() -> dao.insert(record));
    }

    public void delete(BPRecord record) {
        executor.execute(() -> dao.delete(record));
    }

    public void deleteAll() {
        executor.execute(dao::deleteAll);
    }
}
