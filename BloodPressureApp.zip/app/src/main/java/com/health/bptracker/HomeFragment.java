package com.health.bptracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private BPViewModel viewModel;
    private TextView tvSystolic, tvDiastolic, tvHeartRate;
    private TextView tvCategory, tvLastTime;
    private TextView tvAvgSystolic, tvAvgDiastolic, tvAvgHeart;
    private TextView tvGreeting;
    private View cardStatus;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        tvSystolic = view.findViewById(R.id.tv_systolic);
        tvDiastolic = view.findViewById(R.id.tv_diastolic);
        tvHeartRate = view.findViewById(R.id.tv_heart_rate);
        tvCategory = view.findViewById(R.id.tv_category);
        tvLastTime = view.findViewById(R.id.tv_last_time);
        tvAvgSystolic = view.findViewById(R.id.tv_avg_systolic);
        tvAvgDiastolic = view.findViewById(R.id.tv_avg_diastolic);
        tvAvgHeart = view.findViewById(R.id.tv_avg_heart);
        tvGreeting = view.findViewById(R.id.tv_greeting);
        cardStatus = view.findViewById(R.id.card_status);

        ExtendedFloatingActionButton fabAdd = view.findViewById(R.id.fab_add);
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AddRecordActivity.class);
            startActivity(intent);
        });

        viewModel = new ViewModelProvider(requireActivity()).get(BPViewModel.class);
        viewModel.getRecentRecords(30).observe(getViewLifecycleOwner(), this::updateUI);

        setGreeting();
        return view;
    }

    private void setGreeting() {
        int hour = new Date().getHours();
        String greeting;
        if (hour < 6) greeting = "深夜好，注意休息";
        else if (hour < 12) greeting = "早上好，开始美好的一天";
        else if (hour < 14) greeting = "中午好，别忘了量血压";
        else if (hour < 18) greeting = "下午好，保持健康好心情";
        else greeting = "晚上好，记录今日血压";
        tvGreeting.setText(greeting);
    }

    private void updateUI(List<BPRecord> records) {
        if (records == null || records.isEmpty()) {
            tvSystolic.setText("--");
            tvDiastolic.setText("--");
            tvHeartRate.setText("--");
            tvCategory.setText("暂无记录");
            tvLastTime.setText("点击下方按钮添加第一条记录");
            tvAvgSystolic.setText("--");
            tvAvgDiastolic.setText("--");
            tvAvgHeart.setText("--");
            return;
        }

        // 最新一条
        BPRecord latest = records.get(0);
        tvSystolic.setText(String.valueOf(latest.systolic));
        tvDiastolic.setText(String.valueOf(latest.diastolic));
        tvHeartRate.setText(String.valueOf(latest.heartRate));
        tvCategory.setText(latest.category);

        // 设置状态颜色
        int color;
        switch (latest.category) {
            case "正常": color = 0xFF4CAF50; break;
            case "偏高": color = 0xFFFF9800; break;
            case "1级高血压": color = 0xFFFF5722; break;
            default: color = 0xFFF44336; break;
        }
        tvCategory.setTextColor(color);

        SimpleDateFormat sdf = new SimpleDateFormat("MM月dd日 HH:mm", Locale.CHINA);
        tvLastTime.setText("最后记录：" + sdf.format(new Date(latest.timestamp)));

        // 计算平均值（最近7条）
        int count = Math.min(records.size(), 7);
        int sumSys = 0, sumDia = 0, sumHr = 0;
        for (int i = 0; i < count; i++) {
            sumSys += records.get(i).systolic;
            sumDia += records.get(i).diastolic;
            sumHr += records.get(i).heartRate;
        }
        tvAvgSystolic.setText(String.valueOf(sumSys / count));
        tvAvgDiastolic.setText(String.valueOf(sumDia / count));
        tvAvgHeart.setText(String.valueOf(sumHr / count));
    }
}
