package com.health.bptracker;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class BPViewModel extends AndroidViewModel {
    private final BPRepository repository;
    private final LiveData<List<BPRecord>> allRecords;

    public BPViewModel(Application application) {
        super(application);
        repository = new BPRepository(application);
        allRecords = repository.getAllRecords();
    }

    public LiveData<List<BPRecord>> getAllRecords() {
        return allRecords;
    }

    public LiveData<List<BPRecord>> getRecentRecords(int limit) {
        return repository.getRecentRecords(limit);
    }

    public List<BPRecord> getRecordsSince(long startTime) {
        return repository.getRecordsSince(startTime);
    }

    public void insert(BPRecord record) {
        repository.insert(record);
    }

    public void delete(BPRecord record) {
        repository.delete(record);
    }

    public void deleteAll() {
        repository.deleteAll();
    }
}
