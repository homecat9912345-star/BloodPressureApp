package com.health.bptracker;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "blood_pressure_records")
public class BPRecord {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public int systolic;    // 收缩压（高压）
    public int diastolic;   // 舒张压（低压）
    public int heartRate;   // 心率
    public String note;     // 备注
    public long timestamp;  // 时间戳（毫秒）
    public String category; // 分类：正常/偏高/高血压等

    public BPRecord(int systolic, int diastolic, int heartRate, String note, long timestamp) {
        this.systolic = systolic;
        this.diastolic = diastolic;
        this.heartRate = heartRate;
        this.note = note;
        this.timestamp = timestamp;
        this.category = classifyBP(systolic, diastolic);
    }

    private String classifyBP(int sys, int dia) {
        if (sys < 120 && dia < 80) return "正常";
        if (sys < 130 && dia < 80) return "偏高";
        if (sys < 140 || dia < 90) return "1级高血压";
        if (sys < 180 || dia < 120) return "2级高血压";
        return "高血压危象";
    }
}
